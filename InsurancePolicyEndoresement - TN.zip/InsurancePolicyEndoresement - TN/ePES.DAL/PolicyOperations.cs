﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ePES.Entity;
using ePES.Exceptions;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace ePES.DAL
{
    public class PolicyOperations
    {
        static string ConnStr = ConfigurationManager.ConnectionStrings["conStr"].ToString();
        static SqlConnection ConnObj;
        SqlCommand Command;
        DataTable dtCust = null;
        SqlDataReader Reader = null;

        public PolicyOperations()
        {
            ConnObj = new SqlConnection();
            ConnObj.ConnectionString = ConnStr;
        }

        //search by customer--viewing policy details
        public DataTable GetPolicy_DAL(int custID, DateTime DOB, int PN, string Name) //search
        {
            try
            {
                dtCust = new DataTable(/*int custID*/);
                Command = new SqlCommand("Group2.usp_SearchPolicy", ConnObj);
                Command.CommandType = CommandType.StoredProcedure;
                Command.Parameters.AddWithValue("@CID", custID);  // policy number
                Command.Parameters.AddWithValue("@DOB", DOB); // dob
                Command.Parameters.AddWithValue("@PN", PN); // cust id    OR
                Command.Parameters.AddWithValue("@CName", Name); // cust name
                ConnObj.Open();
                Reader = Command.ExecuteReader();
                if (Reader.HasRows)
                {
                    dtCust.Load(Reader);
                }
            }
            catch (SqlException)
            {

                throw;
            }
            catch(PolicyExceptions)
            {
                throw;
            }
            catch (Exception)
            {

                throw;
            }
            finally
            {
                Reader.Close();
                if (ConnObj.State == ConnectionState.Open) ConnObj.Close();
            }
            return dtCust;
        }
    }
}
